# researchpy
Source code for researchpy. Documentation and licensing information can be found here: https://github.com/researchpy/documentation

##### Citation Recommendation
Bryant. C (2018). Researchpy. https://github.com/researchpy/researchpy
